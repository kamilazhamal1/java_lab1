# TestJavaFX11_windows
[Apache NetBeans 12 + OpenJFX 11 + OpenJDK 11 (windows)]

![Screenshot](Screenshot.png)

OpenJFX: https://gluonhq.com/download/javafx-11-sdk-windows/
